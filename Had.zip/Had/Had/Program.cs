﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Had
{
    struct Pozice
    {
        public Pozice(int x, int y)
        {
            X = x;
            Y = y;
        }
        public int X { get; set; }
        public int Y { get; set; }
    }

    class Program
    {
        //Data důležitá pro hru, zde se dá vše nastavit
        static ConsoleColor BarvaHada = ConsoleColor.DarkBlue;
        static ConsoleColor BarvaZeme = ConsoleColor.DarkGreen;
        static ConsoleColor BarvaZdi = ConsoleColor.DarkMagenta;
        static ConsoleColor BarvaJidla = ConsoleColor.DarkRed;

        static int RustPolicekZaS = 2;  //O kolik políček se had zrychlí po snězení jídla
        static int PridatJidla = 5;     //Kolik kůsů jídla se přidá, když všechno jídlo dojde
        static int SirkaHry = Console.LargestWindowWidth - 4;
        static int VyskaHry = Console.LargestWindowHeight - 3;
        static ConsoleKey Smer = ConsoleKey.RightArrow;

        static int PocetJidla;      //Aktuální stav počtu jídla
        static int PolickoZaMs;   //Jak dlouho trvá, než se had posune o jedno políčko
        static ConsoleColor[,] Hra;
        static List<Pozice> Had;
        static int Skore;

        static void Main(string[] args)
        {
            ConsoleKey konec = ConsoleKey.A;
            Uvod();
            while (konec != ConsoleKey.Escape)
            {
                PolickoZaMs = 200;
                PocetJidla = 0;
                Smer = ConsoleKey.RightArrow;
                Hra = new ConsoleColor[SirkaHry, VyskaHry];
                Had = new List<Pozice>();
                Skore = 0;

                Console.Clear();
                //Uvod();
                NachystejHru();
                VykresliHru();
                VypisStav();
                VeHre();

                Console.Clear();
                Console.WriteLine(" Pro novou hru stiskni libovolnou klávesu.");
                Console.WriteLine(" Pro ukončení programu stiskni Escape.");
                konec = Console.ReadKey().Key;
            }
        }

        //Metody pro vypisování informací do konzole
        static void Uvod()
        {
            Console.CursorVisible = false;
            Console.SetWindowPosition(0, 0);
            Console.SetWindowSize(SirkaHry, VyskaHry + 3);
            Console.Title = "Hra Had od Ondry Krsičky";
            VypisInfo();
            Console.WriteLine("Stiskni ENTER");
            Console.ReadKey();
            Console.Clear();
        }
        static void VypisInfo()
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine($"Barva Hada:      {BarvaHada.ToString()}");
            Console.WriteLine($"Barva Země:      {BarvaZeme.ToString()}");
            Console.WriteLine($"Barva Zdi:       {BarvaZdi.ToString()}");
            Console.WriteLine($"Barva Jídla:     {BarvaJidla.ToString()}");
            Console.WriteLine($"Ovládání:        Šipky");
        }
        static void VypisStav()
        {
            Console.SetCursorPosition(0, VyskaHry);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine($"Skóre:           {Skore} bodů");
            Console.WriteLine($"Rychlost Hada:   {1000 / PolickoZaMs} políček za sekundu");
        }
        static void VykresliPolicko(int x, int y, ConsoleColor barva)
        {
            Console.SetCursorPosition(x, y);
            Console.BackgroundColor = barva;
            Console.Write(' ');
        }
        static void VykresliHru()
        {
            for (int y = 0; y < VyskaHry; y++)
            {
                for (int x = 0; x < SirkaHry; x++)
                {
                    VykresliPolicko(x, y, Hra[x, y]);
                }
            }
            Console.WriteLine();
        }

        //Samotná logika hry
        static void NachystejHru()
        {
            for (int y = 0; y < VyskaHry; y++)
            {
                for (int x = 0; x < SirkaHry; x++)
                {
                    if (x == 0 || y == 0 || x == SirkaHry - 1 || y == VyskaHry - 1)
                    {
                        Hra[x, y] = BarvaZdi;
                    }
                    else
                    {
                        Hra[x, y] = BarvaZeme;
                    }
                }
            }

            Had.Add(new Pozice(3, 2));
            Had.Add(new Pozice(2, 2));
            Hra[3, 2] = BarvaHada;
            Hra[2, 2] = BarvaHada;

            Skore = 0;
            PridejJidlo();
        }
        static void VeHre()
        {
            while (true)
            {
                if (Console.KeyAvailable)
                {
                    ConsoleKey vstup = Console.ReadKey().Key;
                    if (vstup != Smer)
                    {
                        if (vstup == ConsoleKey.UpArrow ||
                            vstup == ConsoleKey.DownArrow ||
                            vstup == ConsoleKey.LeftArrow ||
                            vstup == ConsoleKey.RightArrow)
                        {
                            //Zajištění, že had se najednou nevydá doprotisměru ("nekousne se" do článku za hlavou) 
                            if (!(vstup == ConsoleKey.UpArrow && Smer == ConsoleKey.DownArrow) &&
                                !(vstup == ConsoleKey.DownArrow && Smer == ConsoleKey.UpArrow) &&
                                !(vstup == ConsoleKey.LeftArrow && Smer == ConsoleKey.RightArrow) &&
                                !(vstup == ConsoleKey.RightArrow && Smer == ConsoleKey.LeftArrow))
                            {
                                Smer = vstup;
                            }
                        }
                    }
                }

                //Zjištění pozice cílového políčka
                Pozice cil = Had[0];
                switch (Smer)
                {
                    case (ConsoleKey.UpArrow):
                        cil.Y = Had[0].Y - 1; break;
                    case (ConsoleKey.DownArrow):
                        cil.Y = Had[0].Y + 1; break;
                    case (ConsoleKey.RightArrow):
                        cil.X = Had[0].X + 1; break;
                    case (ConsoleKey.LeftArrow):
                        cil.X = Had[0].X - 1; break;
                }

                //Reakce na typ políčka. Např zeď - konec hry, jídlo - prodlouží se had...
                ConsoleColor cilovaBarva = Hra[cil.X, cil.Y];
                if (cilovaBarva == BarvaHada || cilovaBarva == BarvaZdi)
                {
                    break;
                }
                else
                {
                    if (cilovaBarva == BarvaJidla || cilovaBarva == BarvaZeme)
                    {
                        Thread.Sleep(PolickoZaMs);
                        Had.Insert(0, cil);
                        Hra[cil.X, cil.Y] = BarvaHada;
                        VykresliPolicko(cil.X, cil.Y, BarvaHada);
                    }
                    if (cilovaBarva == BarvaZeme)
                    {
                        Hra[Had[Had.Count - 1].X, Had[Had.Count - 1].Y] = BarvaZeme;
                        VykresliPolicko(Had[Had.Count - 1].X, Had[Had.Count - 1].Y, BarvaZeme);
                        Had.RemoveAt(Had.Count - 1);
                    }
                    if (cilovaBarva == BarvaJidla)
                    {
                        Skore += 1;

                        int starychPolicek = 1000 / PolickoZaMs;
                        int novychPolicek = starychPolicek + RustPolicekZaS;
                        PolickoZaMs = 1000 / novychPolicek;

                        VypisStav();
                        PocetJidla -= 1;
                        if (PocetJidla == 0) PridejJidlo();
                    }
                }
            }

            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
            Console.WriteLine(" KONEC HRY                           ");
            Console.WriteLine(" Pro ukončení náhledu stiskni ENTER. ");
            while (Console.ReadKey().Key != ConsoleKey.Enter) { }
        }
        static Random nahoda = new Random();
        static void PridejJidlo()
        {
            for (int i = 0; i < PridatJidla; i++)
            {
                int x = nahoda.Next(3, SirkaHry - 3);
                int y = nahoda.Next(3, VyskaHry - 3);
                //Zajištění, že jídlo zakryje pouze a jenom zem - ne hada..
                if (Hra[x, y] == BarvaZeme)
                {
                    Hra[x, y] = BarvaJidla;
                    VykresliPolicko(x, y, BarvaJidla);
                }
                else
                {
                    i--;
                }
            }
            PocetJidla += PridatJidla;
        }
    }
}
