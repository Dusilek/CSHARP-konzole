﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coby_kdyby__4ernobyl
{
    class Program
    {
        
         
           
           static void Main(string[] args)
            {
                Console.WriteLine("ZDE SI PŘEDSTAVTE OBRÁZEK: NA POZADÍ JE MOŘE, V PRAVO SE NACHÁZÍ DVĚ SKLENICE S KOKTEJLY A NALEVO JE NÁPIS ITNETWORK.CZ, IT SOUTĚŽ");

                Console.ReadKey();

                Console.WriteLine("ahoj soudruhu, zadej své jméno, ať tě můžu oslovovat");
                string soudruh = Console.ReadLine();
                Console.WriteLine("děkuji soudruhu " + soudruh);
                Console.WriteLine(" nyní si vyber obtížnost, osboně bych vám soudruhu doporučil komplexní obtížnost");
                Console.WriteLine("jednoduchá - ponoříte se do duše ředitele elektrárny a projdete si pouze konverzací s dispečerem sítě z Kyjeva osudného 25.4.1986 - pro volbu této obtížnosti stiskni 1 na numpadu ");
                Console.WriteLine("střední - ponoříte se jak do kůže ředitele, tak do kůže operátorů a náměstka hlavního inženýra - pro volbu stiskni 2 na numpadu");
                Console.WriteLine("komplexní - zde si projdeš obdobím, od založení elektrárny, až po 1:23:44 26.4.1986 - pro tuto obtížnost stiskni 3 na numpedu");
                string obtiznost = Console.ReadLine();
                int kobtiznost = Int32.Parse(obtiznost);
                switch (obtiznost)
                {
                    case "1":
                        Console.WriteLine("Vybral sis nejlhečí obtížnopst, pro pokračování stiskni enter klávesu");
                        Console.ReadKey();
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.Write("Je ráno 25. dubna. Jsi ředitel jaderné elektrárny. Je nádherné teplé počasí a ty sedíš ve své kanceláři. \n Za několik minut tě čeká porada, kvůli plánované odstávce 4. energobloku ve tvé elektrárně.\n Po pár minutách za tebou již příjdou oba, kterých se test týká. Hlavní inženýr Fomin a jeho náměstek Ďjatlov. \n Ďjatlov ti sdělí, že vše je připraveno k vykonání zkoušky. \nV tu chvíli zazvoní telefon \n");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("Otázka zní, zvedneš ho ANO/NE. Pokud ano, stiskni 1, pokud ne stiskni 2");
                        string telefon = Console.ReadLine();

                        switch (telefon)
                        {
                            case "1":
                                Console.Write("zvednul jsi telefon");
                                Console.WriteLine("z telefonu se ozve mužský hlas, který ti řekne:");
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("\" soudruhu Brujchanove, horzí přetížení sítě, protože naši soudruzi v továrnách dohánějí plán. Musíte s odstávkou 4. bloku počkat\" ");
                                Console.ForegroundColor = ConsoleColor.Yellow;
                                Console.WriteLine("To co ti tento tajtrlík z Kyjeva řekl tě rozhodí, přeci jen tuto oodstávku plánuješ už od března. Otázka zní jak zareaguješ");
                                Console.WriteLine("1. Vyhovíš mu, ale jen na několik hodin");
                                Console.WriteLine("2. Vyhovíš mu na dobu, na jakou bude potřebovat");
                                Console.WriteLine("3. Pošleš ho do háje");
                                Console.WriteLine("pro výběr stiskni klávesu s číslem tvé volby, na numpade");
                                string reakce = Console.ReadLine();
                                switch (reakce)
                                {
                                    case "1":
                                        Console.WriteLine("dispečer je spokojený jak želvička a pokládá telefon. Chceš se dozvědět, jak by jen a pouze po tomto rozhodnutí dopadl příběh?");
                                        Console.WriteLine("ANO/NE - pokud ano, stiskni 1, pokud ne, stiskni 2");
                                        string pribeh = Console.ReadLine();
                                        break;



                                    case "2":
                                        Console.WriteLine("položil jsi telefon a pokračuješ v poradě");


                                        break;
                                    case "3":
                                        Console.WriteLine("dispečera jsi odmítnul");
                                        break;



                                }
                            break;
                            break;

                             
                               
                    case "2":
                            Console.WriteLine("dobře, vybral jsis střední obtížnost, vraťme se tedy někam do šedesátých let minulého století");
                            break;
                    case "3":
                            Console.WriteLine("HMM, těžká obtížnost, budeš se muset snažit, jinak to nebude dobré");
                            break;




                }

                Console.ReadKey();

            }
        }

    } }