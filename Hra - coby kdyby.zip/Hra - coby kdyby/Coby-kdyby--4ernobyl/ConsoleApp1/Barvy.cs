﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Barvy
    {
        public void Modra()
        {
            Console.ForegroundColor = ConsoleColor.Blue;

        }
        public void Cervena()
        {
            Console.ForegroundColor = ConsoleColor.Red;
        }
        public void Zelena()
        {
            Console.ForegroundColor = ConsoleColor.Green;
        }
        public void Ruzova()
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
        }
        public void Zluta()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;


       }
        public void Bila()
        {
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void Seda()
        {
            Console.ForegroundColor = ConsoleColor.Gray;
        }
        public void CistaKonsole()
        {
            Console.Clear();
            Console.SetCursorPosition(0, 0);
        }
    }



}
