﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Velin
    {
        public void ZacatekSmeny()
        {
            Barvy barvy;
            barvy = new Barvy();
            PrubehOsudovaNoc prubehOsudovaNoc;
            prubehOsudovaNoc = new PrubehOsudovaNoc();
            barvy.Cervena();
            Console.WriteLine("než začneš, vyber si postavu, i toto rozhodnutí bude mít vliv na další vývoj hry");
            Console.Write("(1) Alexandr Akimov (vedoucí směny, na které se to všechno stalo, jediný aspoň částečně hratelný)\n (2) Leonid Toptunov (operátor reaktoru té směny, zatím nedokončen)");
            string Operator;
            Operator = Console.ReadLine();
            Console.Clear();
            Console.SetCursorPosition(0, 0);
            switch (Operator)
            {
                case "1":

                    prubehOsudovaNoc.Akimov();
                    break;
                case "2":
                    Console.WriteLine("zde možná někdy něco bude");
                    break;
            }

        }
    }
}
