﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Obtiznost1
    {
        public void LehkaObtiznost()
        {
            Barvy barvy;
            barvy = new Barvy();
            barvy.Cervena();
            Console.WriteLine("vítej v tutoriálu, těšíš se na hovor s dispečerem?");
            Console.ReadKey();
            Telefon telefon;
            telefon = new Telefon();
            telefon.HovorDispecer();
            Console.WriteLine("Dokončil jsi lehkou obtížnost. Pokud chceš jít na střední obtížnost, stiskni jedničku na numpadu, pokud chceš hru ukončit stiskni dvojku na numpadu a potom libovolnou klávesu");
            
        }
        public void StredniObtiznost()
        {
            Velin velin;
            velin = new Velin();
            velin.ZacatekSmeny();
        }
    }
}
