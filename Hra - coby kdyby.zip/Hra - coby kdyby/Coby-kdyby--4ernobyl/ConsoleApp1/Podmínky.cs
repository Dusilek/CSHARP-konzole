﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Podmínky
    {
        private int xenon;
        private int TypReaktoru;
        private int Teplota;
        private int regulačnítyče;
        private int čerpadla;
        public void Xenon(int Xenon)
        {
            xenon = Xenon;
        }
        public void Reaktor(int typReaktoru)
        {
            TypReaktoru = typReaktoru;
        }
        public void teplota(int TEplota)
        {
            Teplota = TEplota;
        }
        public void RegulačníTyče(int Regulačnítyče)
        {
            
        }
        public void Fyzika(int RegulačníTyče, int Čerpadla, int typReaktoru, int Xenon, int TEplota, int nic)
        {
            regulačnítyče = RegulačníTyče;
            xenon = Xenon;
            TypReaktoru = typReaktoru;
            Teplota = TEplota;
            čerpadla = Čerpadla;
            regulačnítyče = RegulačníTyče;
        }
        private void FyzikaReaktoru()

        {
            int[] fyzika = new int[6];
            fyzika[0] = 1; /// regulační tyče
            fyzika[1] = 1; /// xenon
            fyzika[2] = 1; /// typ reaktoru
            fyzika[3] = 1000; /// teplota
            fyzika[4] = 4; /// čerpadla
            fyzika[5] = 1; /// regulační tyče
            fyzika[6] = 1;
            if  (TypReaktoru != 1)
            {
                fyzika[2] = 2;
                if (Teplota > 1000)
                {
                    fyzika[6] = 125; /// kód výbuchu
                }
            }
            else
            {
                if (xenon != 1)
                {
                    fyzika[1] = 2;
                    if(regulačnítyče != 2)
                    {

                    }
                }
            }
        }
    }
}
