﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
           
            Obtiznost1 obtiznost1;
            obtiznost1 = new Obtiznost1();
            Barvy barvy;
            barvy = new Barvy();
            barvy.Cervena();
            Console.WriteLine("!!!NEŽ ZAČNEŠ RÁD BYCH TĚ UPOZORNIL NA PÁR VĚCÍ, TATO HRA NEOBSAHUJE ŽÁDNÉ GRAFICKÉ PRVKY. \nNĚKTERÉ SCÉNÁŘE NEFUNGUJÍ VŮBEC (od A do Z), NĚKTERÉ ČÁSTEČĚ (osudová noc) A JEDINÝ KTERÝ JE KOMPLETNÍ, JE TUTORIÁL. \nPOKUD PO SKONČENÍ OBTÍŽNOSTI BUDEŠ CHTÍT ZKUSIT JINOU OBTÍŽNOST, TAK PO DOTAZU APLIKACE NAPIŠ ano (všechno malým) \nNĚKTERÉ INFORMACE JSOU ZJEDNODUŠENY A NIKDY SE NEMUSELY STÁT\nNEBO BYLY TROCHU UPRAVENY KVŮLI ZJEDNODUŠENÍ HRY\nNAPŘÍKLAD:\n" +
                "BĚHEM OSUDOVÉ NOCI BYLY NA VELÍNĚ I NĚKTEŘÍ LIDÉ Z PŘEDEŠLÉ SMĚNY, TI OVŠEM NEMĚLI ŽÁDNÉ PRAVOMOCE A NEMOHLI SE NĚJAK VMĚŠOVAT DO ŘÍZENÍ (PORUŠILI TO POUZE PÁR VTEŘIN PŘED VÝBUCHEM). ");
            barvy.Modra();
            Console.WriteLine("ZDE SI PŘEDSTAV OBRÁZEK NA KTERÉM JE PLÁŽ, NAPROVO SE NACHÁZÍ DVĚ SKLENICE\n" +
                "S KOKTEJLY A STOJÍ KRÁSNĚ VE STÍNU PALMY. TOMU VŠEMU VÉVODÍ NÁPIS \"IT NETWORK LETNÍ SOUTĚŽ 2019\"\n" +
                "tak to by bylúvodní obrázek" +
                "odkaz  na stránku: www.itnetwork.cz (pokud máte windows 10 můžete si odkaz překopírovat)");
            barvy.Bila();
            Console.WriteLine("ahoj soudruhu, zadej své jméno, ať tě můžu oslovovat");
            string soudruh = Console.ReadLine();
            Console.WriteLine("děkuji soudruhu " + soudruh);
            string pokracovat = "ano";
            Console.WriteLine(" nyní si vyber scénář, osboně bych vám soudruhu doporučil od A do Z");
            do
            {
                Console.WriteLine("Tutoriál - ponoříte se do duše ředitele elektrárny a projdete si pouze konverzací s dispečerem sítě z Kyjeva osudného 25.4.1986, \nale hlavně se naučíte hru ovládat - pro volbu této obtížnosti stiskni 1 na numpadu ");
                Console.WriteLine("Osudová noc - prožijete si poslední hodiny před tím, než vám to bouchne, budes dost schopný operátor, aby k explozi nakonec nedošlo?");
                Console.WriteLine("od A do Z - zde si projdeš obdobím, od založení elektrárny, až po 1:23:44 26.4.1986 - pro tuto obtížnost stiskni 3 na numpedu");
                string obtiznost = Console.ReadLine();

                switch (obtiznost)
                {
                    case "1":
                        Console.Clear();
                        Console.SetCursorPosition(0, 0);
                        obtiznost1.LehkaObtiznost();
                        pokracovat = Console.ReadLine();

                        break;

                    case "2":

                        obtiznost1.StredniObtiznost();
                        break;

                    case "3":
                        Console.WriteLine("ZDE NĚKDY NĚCO MOŽNÁ BUDE");
                        break;



                }
            }
            while (pokracovat == "ano");
             Console.ReadKey();
            

        }  } }
