﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class PrubehOsudovaNoc
    {


        public void Akimov()
        {
            Barvy barvy;
            barvy = new Barvy();
            Podmínky podmínky;
            podmínky = new Podmínky();
            barvy.Cervena();
            Console.WriteLine("Zvolil sis Akimova");
            Console.Write("nyní si navol pár možností, budou mít vliv na průběh tvé směny \n" +
                "1. V kolik příjde Ďjatlov\n(1) Před půlnocí \n(2) po půlnoci \n");
            string vkolikpříšel = Console.ReadLine();
            Console.Write("Byl po telefonátu zvýšen výkon a teprve pár hodin před testem snížen? \n(1) Byl zvýšen \n(2) Nebyl zvýšen \n ");
            string telefonat = Console.ReadLine();

            Console.ReadKey();
            Console.Write("Směna ti sice začíná až za půl hodiny, ale ty jsi ve velíně (blokové dozorně) dřív, aby jsi mohl směnu přebrat a zjistit co se na předešlé směně odehrálo\n" +
                "dozvídáš se, že test, který měl být proveden kolem oběda se musel odložit a bude proveden během tvé směny\n" +
                "Jsi naštvaný? (1) ANO\n(2)NE");
            string nastvanost = Console.ReadLine();
            Console.Write("Pokračuejm \n O půl hodiny později přijde na směnu i zbytek členů velína a mimo jiné i Anatolij  Ďjatlov, náměstek hlavního inženýra\n a jeden z nejůznávanějších jaderných inženýrů SSSR");
            Console.ReadKey();
            barvy.Seda();
            Console.Write("Ďjatlov: Dobrý den soudruzi, vyspali jste se dobře? Jestli ano, můžeme tedy započít test \nV tom se ozve Toptunov, operátor, jenž má nastarosti reaktor:\n\"Ale nám nikdo neřekl postup, co když se něco stane" +
                "\n Ďjatlov ho odbyde: \"nestraš, reaktor RBMK nemůže explodovat, takže jestli ještě někdo nechce strašit, můžeme jít na to. Všichni na své místa\" zavelel. Po chvíli dodal: \" a ty Akimove, pomož tomu nemehlu");
            Console.Write("Zastaneš se svého podřízeného? \n(1) ANO\n(2) NE\n");
            string pomockolegovi = Console.ReadLine();
            int A = int.Parse(pomockolegovi);
            
            if ( A == 1)
               
                    
                        Console.Clear();
                        Console.SetCursorPosition(0, 0);
                        barvy.Modra();
                        Console.Write(" TY SE NA NĚJ OBOŘÍŠ: Ale soudruh Toptunov má pravdu, nikdy jsme na tento test neměli školení a Bůh ví co se s reaktorem stane,když běžel\ntak dlouhou dobu na půl plynu\n");
                        barvy.Seda();
                        Console.WriteLine("ĎJATLOV HNED JAKMILE TO USLYŠÍ:\"máte nějaký problém, jestli neuposlechnete, všechny nás tu vyhodí \na věřte, že nechcete jít pracovat někam na Sibiř.");
                        barvy.Cervena();
                    

                    Console.WriteLine("Ďjatlov vydal příkaz ke snížení výkonu reaktoru. Toptunov ho poslechl a zahájil snižování výkonu, zapomocí zasouvání tyčí");
                    Console.WriteLine("chceš si trochut zahrát s fyzikou a chemii uvnitř reaktoru, nebo to necháme na realistické úrovni(pokud si chceš hry užít víc, zvol možnost ANO?\n(1) ANO \n(2) NE");
                    string hratkysfyzikou = Console.ReadLine();
            int Typreaktoru = 1;
            int xenoni = 1;
            int Teplota = 1000;
            int MaterRegulačníchTyčí = 1;
            int PočetCerpadel = 4;


                    switch (hratkysfyzikou)
                    {
                        case "1":
                    Console.WriteLine("Jakého typu byl reaktor?\n(1) RBMK \n(2) VVER");
                    string typreaktoru = Console.ReadLine();
                    Typreaktoru = int.Parse(typreaktoru);
                    Console.WriteLine("Utvořil se v reaktrou XENON (pokud si zvolil jako reaktor VVER, tak zde zvol NE, později to ošetřím switchem)?\n(1) ANO\n(2) NE");
                    string xenon = Console.ReadLine();
                    xenoni = int.Parse(xenon);
                    Console.WriteLine("Výborně, další otázka: jakou teplotu má reaktor v jádru svého jádra (napiš číslovkou od 100-10000");
                    string teplota = Console.ReadLine();
                    Teplota = int.Parse(teplota);
                    Console.WriteLine("z jakého materiálu byla špička regulačních tyčí\n(1) Grafit\n(2) Reaktor je typu VVER (zvol pouze pokud jsi před tím, zvolil reaktor typu VVER(později bude ošetřeno switchem\n" +
                        "(3) Bóru");
                    string RegulačníTyčeMater = Console.ReadLine();
                    MaterRegulačníchTyčí = int.Parse(RegulačníTyčeMater);
                    Console.WriteLine("Kolik oběhových čerpadel běží (zapiš číslovkou od 0 do 8");
                    string početčerpadel = Console.ReadLine();
                    PočetCerpadel = int.Parse(početčerpadel);
                    Console.WriteLine("Výborně, právě jsi dokončil mixovávní fyziky reaktoru. Nyní se přesuneme o pár minut do předu");
                    break;
                    }
            Console.WriteLine("Pouštíte se do přípravy na test a s Toptunovem začínáte snižovat výkon reaktoru\n" +
                "Výkon ale klesá příliš rychle. Co uděláš: \n" +
                "(1) Budete pokračovat ve zpomalování reaktoru\n" +
                "(2) odstavíte reaktor\n" +
                "(3) přestanete  tlumit reakci a necháte reaktor, aby setrvačností klesl na potřebný výkon");
            string snizovanivykonu = Console.ReadLine();

            switch (snizovanivykonu)
            {
                case "1":
                    break;
                case "2":
                    Console.WriteLine("\"Tohle není dobrý Leonide, radši ho odstavme než bude pozdě\"");
                    Console.WriteLine("S Toptunovem jste se dohodli na odstavení reaktoru. \n" +
                        "vzhldem k tomu že ještě nebylo pozdě, reaktor jste odstavili jako tolikrát před tím");
                    Console.ReadKey();
                    Console.WriteLine("Bohužel pro vás jste byly oba vyhozeni z elektrárny a zbytek života strávíte-n" +
                        "montováním jaderných reaktorů do ponorek někde na Sibiři"); ;
                    break;
                case "3":
                    Console.WriteLine("Po chvíli došlo k tomu, že se výkon propadl pod 700MW a již nešel\n" +
                        "zvýšit");

            }
            

           




        }
    }
}
