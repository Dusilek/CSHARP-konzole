﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Telefon
    {
        public void HovorDispecer()
        {
            Barvy barvy;
            barvy = new Barvy();
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("Jsi ředitel Jaderné elektrárny Vladímíra I. Lenina, obecně známe jako Černobyl. Brzy tě čeká porada, kvůli odstávce 4. bloku tvé eletrárny.");
            barvy.Cervena();
            Console.Write("Těsně před poradnou ti zazvoní telefon, otázka zní, zvedneš ho?\n(1) ANO\n(2) NE");
            string zvednout = Console.ReadLine();
            switch (zvednout)
            {
                case "1":
                    Console.WriteLine("zvednul jsi telefon, pokračuj stiskem libovolné klávesy");
                    Console.WriteLine("Z tolefonu se ozve hlas dispečera sítě z Kyjeva, který říká:");
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("Dobré dopoledne soudruhu Brjuchanove. V jiné jaderné elektrárně došlo k výpadku, takže odstavení vašeho reaktoru by mohlo způsobit nestabilitu sítě. Můžete odstávku odložit?");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("jaká bude tvá odpověď?");
                    Console.Write("(1) Zeptáš se jetsli není jiná možnost \n(2) Řekneš, že plánování tvé odstávky zabralo přlíš mnoho času a ať si najde jiný přísun energie \n" +
                        "(3) Pošleš ho na západ a položíš mu telefo");                        
                    string prubeh1;
                    prubeh1 = Console.ReadLine();
                    switch (prubeh1)
                    {
                        case "1":
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.WriteLine("ODPOVÍDÁŠ: \"A není jíná možnost? Odstávku jsme velice dlouho plánovali a další odložení by pro nás znamenalo velký problém\"");
                            Console.ForegroundColor = ConsoleColor.Blue;
                            Console.ReadKey();
                            Console.WriteLine("DISPEČER ODPOVÍDA: \"Bohužel, všechny elektrárny co můžou, tak jedou.\"");
                            barvy.Cervena();
                            Console.ReadKey();
                            Console.WriteLine("Zeptám se tě, byl by jsi po této odpovědi naštvaný? (1) ANO\n(2) NE");
                            string nastvanost = Console.ReadLine();
                            switch (nastvanost)
                            {
                                case "1":
                                    barvy.Zluta();
                                    Console.WriteLine("ODPOVÍDÁŠ: \"Si ze mě děláte legraci, tohle není můj problém, takže já ho řešit nehodlám. Nashle\"");
                                    barvy.Modra();
                                    Console.WriteLine("Dispečer se jen zakoktá, snaží se něco, říct, ale není mu rozumět a pokládá telefon. ");
                                    barvy.Cervena();
                                    Console.WriteLine("JAK TO DOPADNE: Zřejmě skončíš na pozici ředitele a nejspíš se na ní už nikdy nepodíváš, ale zase nebudeš mít pocit spoluviny na největší jaderné katastrofě. \nBer to pozitivně a začni už konečně těžit to uhlí");
                                    
                                    break;
                                case "2":
                                    barvy.Zluta();
                                    Console.WriteLine("Dobře, odstávku odložíme. Až budeme moc začít, zavolejte");
                                    barvy.Cervena();
                                    break;
                            }
                            break;
                        case "2":
                            Console.WriteLine("ODPOVÍDÁŠ: \"Si ze mě děláte legraci, tohle není můj problém, takže já ho řešit nehodlám. Nashle\"");
                            barvy.Modra();
                            Console.WriteLine("Dispečer se jen zakoktá, snaží se něco, říct, ale není mu rozumět a pokládá telefon. ");
                            barvy.Cervena();
                            Console.WriteLine("JAK TO DOPADNE: Zřejmě skončíš na pozici ředitele a nejspíš se na ní už nikdy nepodíváš, ale zase nebudeš mít pocit spoluviny na největší jaderné katastrofě. \nBer to pozitivně a začni už konečně těžit to uhlí");
                            break;
                        case "3":
                            Console.WriteLine("ODPOVÍDÁŠ: \"Si ze mě děláte legraci, tohle není můj problém, takže já ho řešit nehodlám. Nashle\"");
                            barvy.Modra();
                            Console.WriteLine("Dispečer se jen zakoktá, snaží se něco, říct, ale není mu rozumět a pokládá telefon. ");
                            barvy.Cervena();
                            Console.WriteLine("JAK TO DOPADNE: Zřejmě skončíš na pozici ředitele a nejspíš se na ní už nikdy nepodíváš, ale zase nebudeš mít pocit spoluviny na největší jaderné katastrofě. \nBer to pozitivně a začni už konečně těžit to uhlí");
                            break; 
                    }




                    break;
                case "2":
                    Console.WriteLine("telefon jsi nezvednul, hra zde zatím končí. ");
                    break;


                
            }
 

        }

    }
}
