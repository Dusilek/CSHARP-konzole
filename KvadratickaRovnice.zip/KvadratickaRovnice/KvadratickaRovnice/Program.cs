﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KvadratickaRovnice
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Zadejte koeficienty kvadratické rovnice. ax^2 + bx + c = 0");
            Console.WriteLine("Zadejte první číslo:");

            float a;
            while (!float.TryParse(Console.ReadLine(), out a))
                Console.WriteLine("Neplatné číslo, zadejte prosím znovu:");

            float b;
            while (!float.TryParse(Console.ReadLine(), out b))
                Console.WriteLine("Neplatné číslo, zadejte prosím znovu:");

            float c;
            while (!float.TryParse(Console.ReadLine(), out c))
                Console.WriteLine("Neplatné číslo, zadejte prosím znovu:");
           /* int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());*/

            if (a == 0 && b == 0 && c == 0)
                Console.WriteLine("Rovnice = R");
            else
            {
                if (a == 0)
                {
                    if (b == 0)
                        Console.WriteLine("Toto není kvadratická rovnice!");
                    else
                    {
                        double x1 = -c / b;
                        Console.WriteLine("Rovnice je lineární. x1 = {0}", x1);
                    }
                }
                else
                {
                    double d = Math.Pow(b,2) - (4*a*c);
                    if (d > 0)
                    {
                        double x1 = (-b + Math.Sqrt(d)) / (2 * a);
                        double x2 = (-b - Math.Sqrt(d)) / (2 * a);
                        Console.WriteLine("Rovnice má 2 kořeny x1 = {0}, x2 = {1}", x1, x2);
                    }
                    else
                    {
                        if (d < 0)
                            Console.WriteLine("Rovnice nemá řešení!");
                        else
                        {
                            double x1 = -b / (2 * a);
                            Console.WriteLine("x1 = {0}", x1);
                        }
                    }
                }
            }
            Console.ReadKey();
        }
    }
}
