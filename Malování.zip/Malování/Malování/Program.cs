﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Malovani
{
    class Program
    {
        static ConsoleColor barvaPozadi = ConsoleColor.Black;
        static string[,] ulozeni;//aktualni stav kresleni
        static string cesta = "";//nazev cesty, ktera existuje z otevreni souboru skrz tuto aplikaci a nebo z ulozenim
        static int X = 0;//souřadnice X 
        static int Y = 0;//souřadnice Y


        #region Ovladani
        public static void Main(string[] args)
        {
            zacatek();
            ConsoleKeyInfo klavesa;//stav aktualne zmacknute klavesy + while
            while ((klavesa = Console.ReadKey(true)).Key != ConsoleKey.Escape)
            {
                switch (klavesa.Key)
                {
                    //pohyby kurzoru
                    case ConsoleKey.UpArrow:
                        pohyb(0, -1);
                        break;
                    case ConsoleKey.RightArrow:
                        pohyb(1, 0);
                        break;
                    case ConsoleKey.DownArrow:
                        pohyb(0, 1);
                        break;
                    case ConsoleKey.LeftArrow:
                        pohyb(-1, 0);
                        break;

                    //ovladaci prvky                    
                    case ConsoleKey.Enter:
                        {
                            Console.BackgroundColor = ConsoleColor.White; ulozeni = new string[Console.WindowHeight, Console.WindowWidth]; Console.Clear(); help(); kurzorNaStred();
                        }
                        break;
                    case ConsoleKey.U:
                        ulozit();
                        break;
                    case ConsoleKey.N:
                        nacteni();
                        break;
                    case ConsoleKey.H:
                        help();
                        break;

                    //vyber barev
                    case ConsoleKey.A:
                        barvaPozadi = ConsoleColor.DarkCyan;
                        break;
                    case ConsoleKey.V:
                        barvaPozadi = ConsoleColor.DarkBlue;//
                        break;
                    case ConsoleKey.R:
                        barvaPozadi = ConsoleColor.Red;
                        break;
                    case ConsoleKey.B:
                        barvaPozadi = ConsoleColor.Blue;
                        break;
                    case ConsoleKey.Spacebar:
                        barvaPozadi = ConsoleColor.White;//
                        break;
                    case ConsoleKey.E:
                        barvaPozadi = ConsoleColor.Yellow;
                        break;
                    case ConsoleKey.T:
                        barvaPozadi = ConsoleColor.Green;
                        break;
                    case ConsoleKey.Y:
                        barvaPozadi = ConsoleColor.Black;//
                        break;
                    case ConsoleKey.W:
                        barvaPozadi = ConsoleColor.Magenta;
                        break;
                    case ConsoleKey.Q:
                        barvaPozadi = ConsoleColor.Cyan;
                        break;
                    case ConsoleKey.C:
                        barvaPozadi = ConsoleColor.Gray;//
                        break;
                    case ConsoleKey.X:
                        barvaPozadi = ConsoleColor.DarkGray;//
                        break;
                    case ConsoleKey.G:
                        barvaPozadi = ConsoleColor.DarkGreen;
                        break;
                    case ConsoleKey.S:
                        barvaPozadi = ConsoleColor.DarkMagenta;
                        break;
                    case ConsoleKey.F:
                        barvaPozadi = ConsoleColor.DarkRed;
                        break;
                    case ConsoleKey.D:
                        barvaPozadi = ConsoleColor.DarkYellow;
                        break;
                }
            }

        }
        #endregion

        static void zacatek()
        {
            

            cesta = VypisCestu();
            //KDYŽ se program otevře s nějakým souborem = Otevřít pomocí, tak se soubor rovnou načte
            if (cesta != "")
                zobraz(cesta);
            //jinak načte úvodní obrazovka a zeptá se jak velké má být okno a načte prázdné "plátno"
            else
            {
                Console.SetCursorPosition(30, 10);
                Console.WriteLine("Vítejte v programu");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.SetCursorPosition(30, 11);
                Console.Write("MALOVÁNÍ V KONZOLI\n\n");
                
                bool pokracovat;
                Console.SetCursorPosition(5, 14);
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.WriteLine("Zadejte velikost (šířka enter výška enter :D doporučuju  min 80 na 25) ");
                Console.SetCursorPosition(23, 15);
                Console.WriteLine("Maximální velikost je {0} na {1})\n\n", Console.LargestWindowWidth, Console.LargestWindowHeight);
                do
                {
                    Console.WriteLine("Velikost: ");
                    try { Console.SetWindowSize(int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine())); pokracovat = false; }
                    catch { Console.WriteLine("Chyba"); pokracovat = true; }
                } while (pokracovat);

                Console.BackgroundColor = ConsoleColor.White;
                Console.Clear();
                ulozeni = new string[Console.WindowHeight, Console.WindowWidth];
                if (Console.WindowHeight > 19 && Console.WindowWidth > 24)
                    help();
                Console.BackgroundColor = barvaPozadi;
                kurzorNaStred();

            }

        }

        static void help()//vypsani ovladani
        {
            Console.SetCursorPosition(0, 0);
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write("Esc\tkonec\nEnter\tvyčistit\nU\tuložení\nN\tnačtení\nSpace\tbílá");
            Console.Write("\nY\tčerná\nC\tšedá\nX\ttmavě šedá");
            Console.Write("\nQ\tmodrozelená\nA\ttmavě modrozelené\nW\tpurpurová\nS\ttmavěpurpurová\nE\tžlutá\nD\ttmavě žlutá\nR\tčervená\nF\ttmavě červená");
            Console.Write("\nT\tzelená\nG\ttmavě zelená\nB\tmodrá\nV\ttmavě modrá");
        }

        static void kurzorNaStred()//nastaveni kurzoru na střed
        {
            X = Console.WindowWidth / 2;
            Y = Console.WindowHeight / 2;
            Console.SetCursorPosition(X, Y);
        }

        static void noveOkno()//pro pohodlnost - upravi konzoli pro vypsani něčeho
        {
            Console.SetWindowSize(80,25);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.DarkGreen;
        }
        #region Pohyb a malování
        static void pohyb(int xPohyb, int yPohyb)//prijima z ovladani
        {
            if (VlezeSeDoOkna(X + xPohyb, Y + yPohyb))//když se vleze kurzor do okna
            {

                X = X + xPohyb;
                Y = Y + yPohyb;
                Console.BackgroundColor = barvaPozadi;//nastavi se barva na psani
                Console.SetCursorPosition(X, Y);
                Console.Write(" \b");// mezera - aby se vypsala barva; \b vrati kurzor o jedno zpet, aby blikal na aktualnim miste
                ulozeni[Y, X] = barvaPozadi.ToString();//ulozi se do pole
            }


        }
        static bool VlezeSeDoOkna(int xKeKontrole, int yKeKontrole)//kontroluje jestli by se kurzor vlezl do okna
        {
            if ((xKeKontrole < 0 || xKeKontrole >= Console.WindowWidth))
                return false;
            if (yKeKontrole < 0 || yKeKontrole >= Console.WindowHeight)
                return false;
            return true;
        }

        #endregion

        #region Uložení

        static void ulozit()
        {
            noveOkno();
            string nazev = "";//promenna pro zadani adresy
            if (cesta != "")//cesta je z predchoziho ukladani, nebo z otevirani souboru
            {
                Console.WriteLine("Chcete uložit tento soubor (y/n): ");
                if (Console.ReadLine() == "y")
                    nazev = cesta;
            }

            if (nazev == "")
            {
                Console.WriteLine("Soubor bude uložen do složky s tímto programem");
                Console.Write("Napište název:");
                nazev = Console.ReadLine() + ".cmmm";//přida příponu
            }

            using (StreamWriter sw = new StreamWriter(@nazev))
            {
                for (int i = 0; i < ulozeni.GetLength(0); i++)//pro sloupce
                {
                    for (int j = 0; j < ulozeni.GetLength(1); j++)//pro řádky
                    {
                        sw.Write(ulozeni[i, j] + ";");//; je oddelovac pro nacitani
                    }
                    sw.WriteLine();
                }

            }

            cesta = nazev;//ulozeni adresy pro pozdejsi ulozeni
            vykresli();
            //zobraz(nazev);//zavolání funkce pro zobrazeni se zadanou adresou, aby se obrazek znovu objevil

        }
        #endregion

        #region Načtení a zobrazení
        static void nacteni()//když chce uživatel otevřít soubor, zepta se na adresu a da ten soubor otevrit
        {
            noveOkno();
            Console.WriteLine("Napište adresu(jestli je soubor ve složce s tímto programem, tak stačí napsat jméno):");
            string adresa = Console.ReadLine();

            zobraz(adresa);
        }

        static void zobraz(string adresa)//pripravi soubor na vykresleni- načte ho do paměti
        {
            int pocetSloupcu;

            int pocetRadku = 1;//protoze prvne cteme 1 radek, kvuli poctu sloupcu

            using (StreamReader sr = new StreamReader(@adresa)) //viz prace se soubory
            {
                string s = sr.ReadLine();//cteme 1 radek, kvuli poctu sloupcu
                string[] jedenRadek = s.Split(';');//pole vznikle rozdelenim radku podle znaku ';'
                pocetSloupcu = jedenRadek.Length - 1;//-1 kvuli ; na konci radku (z duvodu ulozeni)
                while ((s = sr.ReadLine()) != null)//nacteme zbytek radku
                {
                    pocetRadku++;

                }
            }
            string[,] nacitani = new string[pocetRadku, pocetSloupcu];//vytvorime se 2-rozmerne pole jako je ulozeni
            using (StreamReader srn = new StreamReader(@adresa))
            {
                string r;//vytvorime si string r, do ktereho budeme cist radek
                for (int i = 0; i < pocetRadku; i++)//radky
                {
                    r = srn.ReadLine();//cteme do r radek
                    string[] pole = r.Split(';');//rozdelime pomoci znaku ; - viz ulozeni
                    for (int j = 0; j < pocetSloupcu; j++)//jednotliva policka
                    {
                        nacitani[i, j] = pole[j];//ulozeni do nacitani barvy
                    }

                }

            }
            ulozeni = nacitani;
            vykresli();
        }
        static void vykresli()//pozdeji rozdelena funkce zobraz, kvuli vyssimu vykonu
        {
            Console.SetWindowSize(ulozeni.GetLength(1), ulozeni.GetLength(0));//nastavi velikost okna jako ma obrazek
            Console.BackgroundColor = ConsoleColor.White; // pripravi pozadi
            Console.Clear();

            for (int i = 0; i < ulozeni.GetLength(0); i++) //pro kazdy radek v ulozeni
            {
                for (int j = 0; j < ulozeni.GetLength(1); j++)//pro kazdy sloupec
                {
                    Console.SetCursorPosition(j, i);//nastavi pozici na misto na obrazku
                    if (prevodNaBarvu(ulozeni[i, j], out barvaPozadi)) //prevodNaBarvu vraci bool proto if,  
                    {
                        Console.BackgroundColor = barvaPozadi; //nastavi tu spravnou barvu, podle ulozene hodnoty, pokud nejaka je, viz o radek vys
                        Console.Write(" ");//vypise zadany text v dane barve
                    }

                }
            }

            if (barvaPozadi == ConsoleColor.White)//nastaveni aby to psalo
                barvaPozadi = ConsoleColor.Black;

        }

        static bool prevodNaBarvu(string x, out ConsoleColor y)//vraci jestli to jde a nastavuje barvu,ktera je tam ulozena
        {
            bool lze = true;
            y = ConsoleColor.White;
            try
            {
                y = (ConsoleColor)Enum.Parse(typeof(ConsoleColor), x, true);//prevadi string na barvu
            }
            catch
            {
                lze = false;
            }
            return lze;
        }
        public static string VypisCestu()//vypise cestu k souboru, ktery byl spusten pres tuhle aplikaci
        {
            string[] cesta = Environment.GetCommandLineArgs();//je tam vzdy adresa aplikace + adresa souboru
            string adresa = "";
            foreach (string s in cesta)
            {
                if (!s.EndsWith("exe"))//je tam vzdy adresa aplikace + adresa souboru
                    adresa = s;
            }
            return adresa;
        }

        #endregion
    }
}