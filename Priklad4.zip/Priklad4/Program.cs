﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Priklad4
{
    // Vypíše sudá čísla z 1. intervalu, která mají dvojnásobek v druhém intervalu

    /*
     *	       __          __                __            
     *	  ____/ /__ _   __/ /_  ____  ____  / /__ _________
     *	 / __  / _ \ | / / __ \/ __ \/ __ \/ //_// ___/_  /
     *	/ /_/ /  __/ |/ / /_/ / /_/ / /_/ / ,< _/ /__  / /_
     *	\__,_/\___/|___/_.___/\____/\____/_/|_(_)___/ /___/
     *                                                   
     *                                                           
     *      TUTORIÁLY  <>  DISKUZE  <>  KOMUNITA  <>  SOFTWARE
     * 
     *	Tento zdrojový kód je součástí tutoriálů na programátorské 
     *	sociální síti DEVBOOK.CZ	
     *	
     *	Kód můžete upravovat pod licencí MIT, 
     *	tedy jak chcete, jen zmiňte odkaz na www.devbook.cz :-) 
     */

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vypíše sudá čísla z 1. intervalu, která mají dvojnásobek v druhém intervalu.");
            Console.WriteLine("Zadejte levou mez 1. intervalu: ");
            int levaMez1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Zadejte pravou mez 1. intervalu: ");
            int pravaMez1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Zadejte levou mez 2. intervalu: ");
            int levaMez2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Zadejte pravou mez 2. intervalu: ");
            int pravaMez2 = int.Parse(Console.ReadLine());

            Console.Write("Suda cisla z 1. intervalu, ktera maji dvojnasobek v 2. intervalu jsou: ");
            for (int i = levaMez1; i <= pravaMez1; i++)
            {
                if (i % 2 == 0) // kontrola přítomnosti
                {
                    if (((i * 2) <= pravaMez2) && ((i * 2) >= levaMez2))
                        Console.Write("{0}, ", i);
                }
            }
            Console.ReadKey();
        }
    }
}
