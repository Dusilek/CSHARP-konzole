﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Priklad6
{

    // Vypíše čísla fibonacciho posloupnosti pozpátku od zadané meze do 1

    /*
     *	       __          __                __            
     *	  ____/ /__ _   __/ /_  ____  ____  / /__ _________
     *	 / __  / _ \ | / / __ \/ __ \/ __ \/ //_// ___/_  /
     *	/ /_/ /  __/ |/ / /_/ / /_/ / /_/ / ,< _/ /__  / /_
     *	\__,_/\___/|___/_.___/\____/\____/_/|_(_)___/ /___/
     *                                                   
     *                                                           
     *      TUTORIÁLY  <>  DISKUZE  <>  KOMUNITA  <>  SOFTWARE
     * 
     *	Tento zdrojový kód je součástí tutoriálů na programátorské 
     *	sociální síti DEVBOOK.CZ	
     *	
     *	Kód můžete upravovat pod licencí MIT, 
     *	tedy jak chcete, jen zmiňte odkaz na www.devbook.cz :-) 
     */

    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Vypíše čísla fibonacciho posloupnosti pozpátku od zadané meze do 1\nZadejte mez: ");
            int x = int.Parse(Console.ReadLine());

            List<int> fib = new List<int>();

            // vygenerování hodnot do pole od 1
            if (x >= 0) 
                fib.Add(0);
            if (x >= 1) 
                fib.Add(1);
            int i = 2;
            int cislo;

            do
            {
                cislo = (fib[i - 1]) + (fib[i - 2]);
                if (cislo <= x) 
                    fib.Add(cislo);
                i++;
            } while (cislo <= x);

            fib.Reverse(); // převrácení pole

            // výpis
            foreach (int a in fib)
            {
                Console.Write("{0}, ", a);
            }

            Console.ReadKey();
        }
    }
}
