﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Priklad7
{

    // Vypíše čísla fibonacciho posloupnosti v daném intervalu

    /*
     *	       __          __                __            
     *	  ____/ /__ _   __/ /_  ____  ____  / /__ _________
     *	 / __  / _ \ | / / __ \/ __ \/ __ \/ //_// ___/_  /
     *	/ /_/ /  __/ |/ / /_/ / /_/ / /_/ / ,< _/ /__  / /_
     *	\__,_/\___/|___/_.___/\____/\____/_/|_(_)___/ /___/
     *                                                   
     *                                                           
     *      TUTORIÁLY  <>  DISKUZE  <>  KOMUNITA  <>  SOFTWARE
     * 
     *	Tento zdrojový kód je součástí tutoriálů na programátorské 
     *	sociální síti DEVBOOK.CZ	
     *	
     *	Kód můžete upravovat pod licencí MIT, 
     *	tedy jak chcete, jen zmiňte odkaz na www.devbook.cz :-) 
     */

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vypíše čísla fibonacciho posloupnosti v daném intervalu");
            Console.WriteLine("Zadejte levou mez intervalu: ");
            int levaMez = int.Parse(Console.ReadLine());
            Console.WriteLine("Zadejte pravou mez intervalu: ");
            int pravaMez = int.Parse(Console.ReadLine());

            long n = 0; // současný
            long np = 1; // minulý
            long npp = 0; // předminulý

            // 0 a 1
            if (levaMez <= 0)
                Console.Write("{0}, ",0);
            if (levaMez <= 1)
                Console.Write("{1}, ",1);

            // od 2 dál
            do
            {
                n = np + npp;
                npp = np;
                np = n;

                if ((n >= levaMez) && (n <= pravaMez))
                {
                    Console.Write("{0}, ", n);
                }

            } while (n <= pravaMez);

            Console.ReadKey();
        }
    }
}
