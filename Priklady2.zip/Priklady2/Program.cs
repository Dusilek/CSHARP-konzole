﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Priklad1
{
    // pro zadaný interval vypíše součet čísel, které jsou sudé a dělitelné 5

    /*
     *	       __          __                __            
     *	  ____/ /__ _   __/ /_  ____  ____  / /__ _________
     *	 / __  / _ \ | / / __ \/ __ \/ __ \/ //_// ___/_  /
     *	/ /_/ /  __/ |/ / /_/ / /_/ / /_/ / ,< _/ /__  / /_
     *	\__,_/\___/|___/_.___/\____/\____/_/|_(_)___/ /___/
     *                                                   
     *                                                           
     *      TUTORIÁLY  <>  DISKUZE  <>  KOMUNITA  <>  SOFTWARE
     * 
     *	Tento zdrojový kód je součástí tutoriálů na programátorské 
     *	sociální síti DEVBOOK.CZ	
     *	
     *	Kód můžete upravovat pod licencí MIT, 
     *	tedy jak chcete, jen zmiňte odkaz na www.devbook.cz :-) 
     */

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Pro zadaný interval vypíše součet čísel, které jsou sudé a dělitelné 5");
            Console.WriteLine("Zadejte levou mez intervalu: ");
            int levaMez = int.Parse(Console.ReadLine());
            Console.WriteLine("Zadejte pravou mez intervalu: ");
            int pravaMez = int.Parse(Console.ReadLine());
            int soucet = 0;
            for (int i = levaMez; i <= pravaMez; i++)
            {
                if ((i % 5 == 0) && (i % 2 == 0))  // nebo % 10 == 0
                {
                    soucet += i;
                }
            }
            Console.WriteLine("Soucet sudych cisel delitelnych 5: {0}", soucet);
            Console.ReadKey();
        }
    }
}
