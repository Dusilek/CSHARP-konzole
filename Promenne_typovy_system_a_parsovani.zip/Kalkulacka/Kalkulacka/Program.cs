﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kalkulacka
{
    /*
     *	       __          __                __            
     *	  ____/ /__ _   __/ /_  ____  ____  / /__ _________
     *	 / __  / _ \ | / / __ \/ __ \/ __ \/ //_// ___/_  /
     *	/ /_/ /  __/ |/ / /_/ / /_/ / /_/ / ,< _/ /__  / /_
     *	\__,_/\___/|___/_.___/\____/\____/_/|_(_)___/ /___/
     *                                                   
     *                                                           
     *      TUTORIÁLY  <>  DISKUZE  <>  KOMUNITA  <>  SOFTWARE
     * 
     *	Tento zdrojový kód je součástí tutoriálů na programátorské 
     *	sociální síti DEVBOOK.CZ	
     *	
     *	Kód můžete upravovat pod licencí MIT, 
     *	tedy jak chcete, jen zmiňte odkaz na www.devbook.cz :-) 
     */

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vítejte v kalkulačce");
            Console.WriteLine("Zadejte první číslo:");
            float a = float.Parse(Console.ReadLine());
            Console.WriteLine("Zadejte druhé číslo:");
            float b = float.Parse(Console.ReadLine());
            float soucet = a + b;
            float rozdil = a - b;
            float soucin = a * b;
            float podil = a / b;
            Console.WriteLine("Součet: " + soucet);
            Console.WriteLine("Rozdíl: " + rozdil);
            Console.WriteLine("Součin: " + soucin);
            Console.WriteLine("Podíl: " + podil);
            Console.WriteLine("Děkuji za použití kalkulačky, aplikace ukončíte libovolnou klávesou.");
            Console.ReadKey();
        }
    }
}
