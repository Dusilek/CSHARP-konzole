﻿using System;

namespace PřevodnikSoustav
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("PŘEVODNÍK SOUSTAV \n");
            bool pokracovat = true;

            while (pokracovat)
            {

                // Zadání vstupní soustavy
                Console.WriteLine("Vstupní soustava - (2 - 36)");
                ulong vstupniSoustava = 0;
                // Validace
                while (!(vstupniSoustava >= 2 && vstupniSoustava <= 36))
                {
                    ulong.TryParse(Console.ReadLine().Trim().Replace(" ", ""), out vstupniSoustava);
                    if (!(vstupniSoustava >= 2 && vstupniSoustava <= 36))
                        Console.WriteLine("Napište číslo z intervalu (2, 36)");
                }

                // Zadání výstupní soustavy
                Console.WriteLine("Výstupní soustava - (2 - 36)");
                ulong vystupniSoustava = 0;
                // Validace
                while (!(vystupniSoustava >= 2 && vystupniSoustava <= 36))
                {
                    ulong.TryParse(Console.ReadLine().Trim().Replace(" ", ""), out vystupniSoustava);
                    if (!(vystupniSoustava >= 2 && vystupniSoustava <= 36))
                        Console.WriteLine("Napište číslo z intervalu (2, 36)");
                }

                // Proměnné
                string vstupString = "";
                string meziVystup = "";
                string vystup = "";
                double vystupCislo = 0;
                string hodnotyPrevodu = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

                //Převod z libovolné soustavy do libovolné soustavy
                Console.WriteLine("Zadejte číslo pro převod");

                // převod z libovolné soustavy do 10
                // Validace
                bool jePlatne = false;
                while (!jePlatne)
                {
                    jePlatne = true;
                    vstupString = Console.ReadLine().ToUpper().Trim().Replace(" ", "");
                    foreach (char c in vstupString)
                    {
                        hodnotyPrevodu.IndexOf(c);
                        if ((hodnotyPrevodu.IndexOf(c) > Convert.ToInt32(vstupniSoustava) - 1) || !hodnotyPrevodu.Contains(c))
                        {
                            jePlatne = false;
                            Console.WriteLine("Zadejte číslo ve správném formátu");
                            break;
                        }
                    }
                }
                if (vstupniSoustava != vystupniSoustava)
                {
                    // Výpočet
                    for (int i = 0; i < vstupString.Length; i++)
                    {
                        int index = hodnotyPrevodu.IndexOf(vstupString[i]);
                        if (index >= 1)
                            vystupCislo += (Math.Pow(vstupniSoustava, vstupString.Length - (i + 1)) * index);
                    }

                    // převod z 10 do libovolné soustavy
                    ulong prevod = Convert.ToUInt64(vystupCislo);
                    while (prevod != 0)
                    {
                        meziVystup += hodnotyPrevodu[Convert.ToInt32(prevod % vystupniSoustava)];
                        prevod /= vystupniSoustava;
                    }
                    for (int i = meziVystup.Length - 1; i >= 0; i--)
                        vystup += meziVystup[i];

                }
                else
                    vystup = vstupString;

                // Výsledek
                Console.WriteLine("Výsledek je: {0}", vystup);

                // Dotaz na opakování
                Console.WriteLine("Přejete si pokračovat? [a/n]");
                bool pokracovatAnoNe = true;
                while (pokracovatAnoNe)
                {
                    char volbaPokracovat = Console.ReadKey().KeyChar;
                    switch (volbaPokracovat)
                    {
                        case 'a':
                            Console.WriteLine();
                            pokracovatAnoNe = false;
                            break;
                        case 'n':
                            Console.WriteLine();
                            pokracovatAnoNe = false;
                            pokracovat = false;
                            break;
                        default:
                            Console.WriteLine();
                            Console.WriteLine("Neplatná volba, zadejte [a/n]");
                            pokracovatAnoNe = true;
                            break;
                    }
                }

            }
        }
    }
}
