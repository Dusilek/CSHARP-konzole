﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ram_in_c_sharp
{
    class Program
    {
        static void Main(string[] args)
        {
            RAM ram = new RAM();
            Console.WriteLine("Zvolte co chcete dělat:");
            string pokracovat = "ano";
            byte data = 0;
            byte adresaW = 0;
            byte adresaR = 0;
            while (pokracovat == "ano")
            {
                Console.WriteLine("1. uložit \n2. číst");
                byte volba = byte.Parse(Console.ReadLine());
                switch (volba)
                {
                    case 1:
                        Console.WriteLine("Zadejte data, které chcete uložit (0-255):");
                        data = byte.Parse(Console.ReadLine());
                        Console.WriteLine("Zadejte adresu na, kterou chcete data uložit (0-255):");
                        adresaW = byte.Parse(Console.ReadLine());
                        Console.WriteLine("Data " + ram.writing(data, adresaW) + " uložena na adresu " + adresaW);
                        break;
                    case 2:
                        Console.WriteLine("Zadejte adresu ze, které chcete číst (0-255):");
                        adresaR = byte.Parse(Console.ReadLine());
                        Console.WriteLine("Data z adresy " + adresaR + " jsou " + ram.reading(adresaR));
                        break;
                }
                Console.WriteLine("Přejete si pokračovat (ano/ne)?");
                pokracovat = Console.ReadLine();
            }
            Console.WriteLine("Děkuji za použití dočasné paměti, aplikaci ukončíte stisknutím libovolné klávesy.");
            Console.ReadKey();
        }
    }
}
