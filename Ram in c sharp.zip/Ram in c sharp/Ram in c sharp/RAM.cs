﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ram_in_c_sharp
{
    class RAM
    {
        private byte dataOut = 0;

        private byte[] dataHere = new byte[255];

        public byte writing(byte dataIn, byte addressWrite)
        {
            dataHere[addressWrite] = dataIn;
            return dataHere[addressWrite];
        }

        public byte reading(byte addressRead)
        {
            dataOut = dataHere[addressRead];
            return dataOut;
        }
    }
}
