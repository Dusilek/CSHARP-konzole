﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mocninator
{

    /*
     *	       __          __                __            
     *	  ____/ /__ _   __/ /_  ____  ____  / /__ _________
     *	 / __  / _ \ | / / __ \/ __ \/ __ \/ //_// ___/_  /
     *	/ /_/ /  __/ |/ / /_/ / /_/ / /_/ / ,< _/ /__  / /_
     *	\__,_/\___/|___/_.___/\____/\____/_/|_(_)___/ /___/
     *                                                   
     *                                                           
     *      TUTORIÁLY  <>  DISKUZE  <>  KOMUNITA  <>  SOFTWARE
     * 
     *	Tento zdrojový kód je součástí tutoriálů na programátorské 
     *	sociální síti DEVBOOK.CZ	
     *	
     *	Kód můžete upravovat pod licencí MIT, 
     *	tedy jak chcete, jen zmiňte odkaz na www.devbook.cz :-) 
     */

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mocninátor");
            Console.WriteLine("==========");
            Console.WriteLine("Zadejte základ mocniny: ");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Zadejte exponent: ");
            int n = int.Parse(Console.ReadLine());

            int vysledek = a;
            for (int i = 0; i < (n - 1); i++)
                vysledek = vysledek * a;

            Console.WriteLine("Výsledek: {0}", vysledek);
            Console.WriteLine("Děkuji za použití mocninátoru");
            Console.ReadKey();
        }
    }
}
