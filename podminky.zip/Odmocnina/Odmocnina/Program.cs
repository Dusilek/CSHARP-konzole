﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Odmocnina
{

    /*
     *	       __          __                __            
     *	  ____/ /__ _   __/ /_  ____  ____  / /__ _________
     *	 / __  / _ \ | / / __ \/ __ \/ __ \/ //_// ___/_  /
     *	/ /_/ /  __/ |/ / /_/ / /_/ / /_/ / ,< _/ /__  / /_
     *	\__,_/\___/|___/_.___/\____/\____/_/|_(_)___/ /___/
     *                                                   
     *                                                           
     *      TUTORIÁLY  <>  DISKUZE  <>  KOMUNITA  <>  SOFTWARE
     * 
     *	Tento zdrojový kód je součástí tutoriálů na programátorské 
     *	sociální síti DEVBOOK.CZ	
     *	
     *	Kód můžete upravovat pod licencí MIT, 
     *	tedy jak chcete, jen zmiňte odkaz na www.devbook.cz :-) 
     */

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Zadej nějaké číslo, ze kterého spočítám odmocninu:");
            int a = int.Parse(Console.ReadLine());
            if (a > 0)
            {
                Console.WriteLine("Zadal jsi číslo větší než 0, to znamená, že ho mohu odmocnit!");
                double o = Math.Sqrt(a);
                Console.WriteLine("Odmocnina z čísla " + a + " je " + o);
            }
            else
                Console.WriteLine("Odmocnina ze záporného čísla neexistuje!");
            Console.WriteLine("Dzkuji za zadání");
            Console.ReadKey();
        }
    }
}
