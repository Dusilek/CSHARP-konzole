﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NaplneniAVypisPole
{

    /*
     *  _____ _______         _                      _
     * |_   _|__   __|       | |                    | |
     *   | |    | |_ __   ___| |___      _____  _ __| | __  ___ ____
     *   | |    | | '_ \ / _ \ __\ \ /\ / / _ \| '__| |/ / / __|_  /
     *  _| |_   | | | | |  __/ |_ \ V  V / (_) | |  |   < | (__ / /
     * |_____|  |_|_| |_|\___|\__| \_/\_/ \___/|_|  |_|\_(_)___/___|
     *                   ___
     *                  |  _|___ ___ ___
     *                  |  _|  _| -_| -_|  LICENCE
     *                  |_| |_| |___|___|
     *
     * IT ZPRAVODAJSTVÍ  <>  PROGRAMOVÁNÍ  <>  HW A SW  <>  KOMUNITA
     *
     * Tento zdrojový kód pochází z IT sociální sítě WWW.ITNETWORK.CZ
     *
     * Můžete ho upravovat a používat jak chcete, musíte však zmínit
     * odkaz na http://www.itnetwork.cz
     */

    class Program
    {
        static void Main(string[] args)
        {
            int[] pole = new int[10];
            pole[0] = 1;
            for (int i = 0; i < 10; i++)
                pole[i] = i + 1;
            foreach (int i in pole)
                Console.Write("{0} ", i);
            Console.ReadKey();
        }
    }
}
