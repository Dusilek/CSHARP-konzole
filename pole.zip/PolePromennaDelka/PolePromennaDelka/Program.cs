﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PolePromennaDelka
{

    /*
     *  _____ _______         _                      _
     * |_   _|__   __|       | |                    | |
     *   | |    | |_ __   ___| |___      _____  _ __| | __  ___ ____
     *   | |    | | '_ \ / _ \ __\ \ /\ / / _ \| '__| |/ / / __|_  /
     *  _| |_   | | | | |  __/ |_ \ V  V / (_) | |  |   < | (__ / /
     * |_____|  |_|_| |_|\___|\__| \_/\_/ \___/|_|  |_|\_(_)___/___|
     *                   ___
     *                  |  _|___ ___ ___
     *                  |  _|  _| -_| -_|  LICENCE
     *                  |_| |_| |___|___|
     *
     * IT ZPRAVODAJSTVÍ  <>  PROGRAMOVÁNÍ  <>  HW A SW  <>  KOMUNITA
     *
     * Tento zdrojový kód pochází z IT sociální sítě WWW.ITNETWORK.CZ
     *
     * Můžete ho upravovat a používat jak chcete, musíte však zmínit
     * odkaz na http://www.itnetwork.cz
     */

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ahoj, spočítám ti průměr známek. Kolik známek zadáš?");
            int pocet = int.Parse(Console.ReadLine());
            int[] cisla = new int[pocet];
            for (int i = 0; i < pocet; i++)
            {
                Console.Write("Zadejte {0}. číslo: ", i + 1);
                cisla[i] = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("Průměr tvých známek je: {0}", cisla.Average());
            Console.ReadKey();
        }
    }
}
