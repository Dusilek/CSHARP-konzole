﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnalyzaVyskytuZnaku
{

    /*
     *	       __          __                __            
     *	  ____/ /__ _   __/ /_  ____  ____  / /__ _________
     *	 / __  / _ \ | / / __ \/ __ \/ __ \/ //_// ___/_  /
     *	/ /_/ /  __/ |/ / /_/ / /_/ / /_/ / ,< _/ /__  / /_
     *	\__,_/\___/|___/_.___/\____/\____/_/|_(_)___/ /___/
     *                                                   
     *                                                           
     *      TUTORIÁLY  <>  DISKUZE  <>  KOMUNITA  <>  SOFTWARE
     * 
     *	Tento zdrojový kód je součástí tutoriálů na programátorské 
     *	sociální síti DEVBOOK.CZ	
     *	
     *	Kód můžete upravovat pod licencí MIT, 
     *	tedy jak chcete, jen zmiňte odkaz na www.devbook.cz :-) 
     */

    class Program
    {
        static void Main(string[] args)
        {
            // řetězec, který chceme analyzovat
            string s = "Programátor se zasekne ve sprše, protože instrukce na šampónu byly: Namydlit, omýt, opakovat.";
            Console.WriteLine(s);
            s = s.ToLower();

            // inicializace počítadel
            int pocetSamohlasek = 0;
            int pocetSouhlasek = 0;

            // definice typů znaků
            string samohlasky = "aeiouyáéěíóúůý";
            string souhlasky = "bcčdďfghjklmnpqrřsštťvwxzž";

            // hlavní cyklus
            foreach (char c in s)
            {
                if (samohlasky.Contains(c))
                    pocetSamohlasek++;
                else
                    if (souhlasky.Contains(c))
                        pocetSouhlasek++;
            }

            // Výpisy
            Console.WriteLine("Samohlásek: {0}", pocetSamohlasek);
            Console.WriteLine("Souhlásek: {0}", pocetSouhlasek);
            Console.WriteLine("Nepísmenných znaků: {0}", s.Length - (pocetSamohlasek + pocetSouhlasek));
            Console.ReadKey();
        }
    }
}
